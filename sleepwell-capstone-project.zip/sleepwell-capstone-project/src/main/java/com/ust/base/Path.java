package com.ust.base;

public class Path {

	// Variables containing the string values of object, expected results and excel
	// path.
	public static String object_path = "/src/main/resources/Object Details/object.properties";
	public static String expectedresults_path = "/src/test/resources/Expected Results/expresults.properties";
	public static String excel_path = "/src/main/resources/Test Data/dataset.xlsx";
}
